package ss.week4.math.interfaces;

public interface Integrandable{

	public Function integrand();
}
